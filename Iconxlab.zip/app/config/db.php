<?php   
return array(
    'host'=>'localhost',
    'user'=>'root',
    'password'=>'root',
    'db'=>'test',
    'port'=>3307
);
