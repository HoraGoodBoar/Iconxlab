<?php   
include_once(ROOT.'/app/classes/User.php');

class Student extends User
{
    public $Kind;
    public $GroupF;
    public $Faculty;
}