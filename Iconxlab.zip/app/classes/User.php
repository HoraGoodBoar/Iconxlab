<?php

class User
{
    public $id;
    public $FirstName;
    public $LastName;
    public $Age;
}