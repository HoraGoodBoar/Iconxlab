<?php

class Model
{
    
}