<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top position-static" style="background:#5181b8;">
    <a class="navbar-brand" href="#" style="margin-right:10%;">Dmytro</a>
   
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarCollapse">

      <ul class="navbar-nav mr-auto">
        <li class="nav-item d-block " >
          <a class="nav-link" href="/Iconxlab/students">Students</a>
        </li>

        <li class="nav-item d-block ">
          <a class="nav-link" href="/Iconxlab/registration">Registration</a>
        </li>
      </ul>

    </div>
  </nav>
</header>